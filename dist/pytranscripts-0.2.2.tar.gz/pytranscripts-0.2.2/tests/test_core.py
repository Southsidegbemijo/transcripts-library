from pytranscripts import docx_transcripts_to_excel

def check_transcript_extraction():
    pass

def check_data_classification():
    pass
